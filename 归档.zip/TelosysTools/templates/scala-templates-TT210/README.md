Set of scala templates usable with TelosysTools ver 2.0.4

( https://sites.google.com/site/telosystools/ )
