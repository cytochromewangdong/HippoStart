persistence-jpa
===============

Telosys - Persistence layer - Templates for Java Persistence based on JPA
Telosys - Couche de persistence - Templates de persistence Java basés sur JPA
