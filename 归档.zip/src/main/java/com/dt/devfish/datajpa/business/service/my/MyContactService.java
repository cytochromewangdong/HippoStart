package com.dt.devfish.datajpa.business.service.my;

import java.util.List;

import com.dt.devfish.datajpa.business.service.ContactService;
import com.dt.devfish.datajpa.model.jpa.Contact;

public interface MyContactService extends ContactService {
	List<Contact> findContactByFirstName(String firstName);
}
