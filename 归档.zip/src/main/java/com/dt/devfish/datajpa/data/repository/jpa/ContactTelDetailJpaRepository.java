package com.dt.devfish.datajpa.data.repository.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import com.dt.devfish.datajpa.model.jpa.ContactTelDetail;

/**
 * Repository : ContactTelDetail.
 */
public interface ContactTelDetailJpaRepository extends JpaRepository<ContactTelDetail, Integer> {

}
