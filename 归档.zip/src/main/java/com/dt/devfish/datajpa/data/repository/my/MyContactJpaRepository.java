package com.dt.devfish.datajpa.data.repository.my;

import java.util.List;

import com.dt.devfish.datajpa.data.repository.jpa.ContactJpaRepository;
import com.dt.devfish.datajpa.model.jpa.Contact;

public interface MyContactJpaRepository extends ContactJpaRepository {
	List<Contact> findContactByFirstNameLike(String firstName);
}
